const mongoose = require("mongoose");
const validator = require("validator");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const keysecret =
  process.env.JWT_SECRET_KEY || "key";

const fieldSchema = new mongoose.Schema({
  question: String,
  type: String,
  options: [String],
});

const formSchema = new mongoose.Schema({
  formId: String,
  formTitle: String,
  fields: [fieldSchema],
});

const userSchema = new mongoose.Schema({
  fname: {
    type: String,
    required: true,
    trim: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
    validate(value) {
      if (!validator.isEmail(value)) {
        throw new Error("not valid email");
      }
    },
  },
  password: {
    type: String,
    required: true,
    minlength: 6,
  },
  forms: [formSchema],
  tokens: [{ token: { type: String, required: true } }],
});

userSchema.pre("save", async function (next) {
  if (this.isModified("password")) {
    this.password = await bcrypt.hash(this.password, 12);
  }
  next();
});

userSchema.methods.generateAuthtoken = async function () {
  const maxRetries = 5;
  let retries = 0;

  while (retries < maxRetries) {
    try {
      const token = jwt.sign({ _id: this._id }, keysecret, { expiresIn: "1d" });

      this.tokens = this.tokens.concat({ token });
      await this.save();
      return token;
    } catch (error) {
      if (error.name === "VersionError" && retries < maxRetries - 1) {
        retries++;
        const freshUser = await mongoose.model("users").findById(this._id);

        if (!freshUser) throw new Error("User not found");
        Object.assign(this, freshUser);
      } else {
        console.error("Error generating token:", error);
        throw new Error("Error generating token:" + error.message);
      }
    }
  }

  throw new Error("Max retries reached while generating token");
};

const userdb = mongoose.model("users", userSchema);

module.exports = userdb;

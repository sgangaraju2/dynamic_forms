import React, { useState } from 'react';
import { toast } from 'react-toastify';

const UserForm = () => {
    const [formData, setFormData] = useState({
        field1: '',
        field2: '', // Add more fields as needed
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch("/api/forms", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${localStorage.getItem("usersdatatoken")}`
                },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                toast.success("Form submitted successfully!");
            } else {
                toast.error("Failed to submit form.");
            }
        } catch (error) {
            console.error("Error submitting form:", error);
            toast.error("An error occurred. Please try again.");
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input
                type="text"
                name="field1"
                value={formData.field1}
                onChange={handleChange}
                placeholder="Field 1"
            />
            <input
                type="text"
                name="field2"
                value={formData.field2}
                onChange={handleChange}
                placeholder="Field 2"
            />
            <button type="submit">Submit</button>
        </form>
    );
};

export default UserForm;
import React, { useContext, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LoginContext } from './ContextProvider/Context';
import CircularProgress from '@mui/material/CircularProgress';
import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';
import './Dashboard.css';

const Dashboard = () => {
  const { logindata, setLoginData } = useContext(LoginContext);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [responses, setResponses] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [formTitle, setFormTitle] = useState('');
  const [fields, setFields] = useState([{ question: '', type: 'text', options: [] }]);
  const history = useNavigate();

  useEffect(() => {
    const initializeDashboard = async () => {
      await DashboardValid();
      await fetchUserForms();
      await fetchSubmissions();
    };
    initializeDashboard();
  }, []);

  const getToken = () => localStorage.getItem("usersdatatoken");

  const DashboardValid = async () => {
    const token = getToken();
    if (!token) {
      setError("No authentication token found");
      setIsLoading(false);
      return;
    }

    try {
      const res = await fetch("http://localhost:8009/api/validuser", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        credentials: 'include'
      });
      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
      const data = await res.json();
      if (!data || data.status === 401) {
        setError("User not authorized");
        history("/");
      } else {
        setLoginData(data.validUser);
      }
    } catch (err) {
      console.error("Error validating user:", err);
      setError(`An error occurred while validating user: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchUserForms = async () => {
    const token = getToken();
    try {
      const res = await fetch("http://localhost:8009/api/forms", {
        method: "GET",
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setResponses(data.forms || []);
      } else {
        throw new Error("Failed to fetch forms");
      }
    } catch (err) {
      console.error("Error fetching forms:", err);
      setError("An error occurred while fetching forms.");
    }
  };

  const fetchSubmissions = async () => {
    const token = getToken();
    try {
      const res = await fetch("http://localhost:8009/api/submissions", {
        method: "GET",
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setSubmissions(data.submissions || []);
      } else {
        throw new Error("Failed to fetch submissions");
      }
    } catch (err) {
      console.error("Error fetching submissions:", err);
      setError("An error occurred while fetching submissions.");
    }
  };

  // Function to handle form submission
  const handleFormSubmit = async (e) => {
    e.preventDefault();
    const token = getToken();
    const formId = Math.random().toString(36).substr(2, 9);
    try {
      const response = await fetch("http://localhost:8009/api/forms", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ formTitle, fields, formId })
      });
      if (response.ok) {
        fetchUserForms();
        setSnackbarMessage("Form created successfully!");
        setSnackbarOpen(true);
        setFormTitle('');
        setFields([{ question: '', type: 'text', options: [] }]);
      } else {
        throw new Error("Failed to save form.");
      }
    } catch (error) {
      console.error("Error saving form:", error);
      setError("An error occurred while saving the form.");
    }
  };

  // Function to handle form deletion
  const deleteForm = async (formId) => {
    console.log("Attempting to delete form with ID:", formId);
    const token = getToken();
    try {
      const res = await fetch(`http://localhost:8009/api/forms/${formId}`, {
        method: "DELETE",
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (res.ok) {
        // Update UI by removing the deleted form
        setResponses(responses.filter(form => form.formId !== formId));
        setSnackbarMessage("Form deleted successfully!");
        setSnackbarOpen(true);
      } else {
        throw new Error("Failed to delete form");
      }
    } catch (err) {
      console.error("Error deleting form:", err);
      setError("An error occurred while deleting the form.");
    }
  };

  // Functions to manage fields
  const addField = () => {
    setFields([...fields, { question: '', type: 'text', options: [] }]);
  };

  const removeField = (index) => {
    setFields(fields.filter((_, i) => i !== index));
  };

  const handleFieldChange = (index, event) => {
    const newFields = [...fields];
    newFields[index][event.target.name] = event.target.value;
    if (event.target.name === 'type' && event.target.value !== 'checkbox') newFields[index].options = [];
    setFields(newFields);
  };

  const handleOptionChange = (fieldIndex, optionIndex, event) => {
    const newFields = [...fields];
    newFields[fieldIndex].options[optionIndex] = event.target.value;
    setFields(newFields);
  };

  const addOptionField = (index) => {
    if (fields[index].type !== 'text') {
      const newFields = [...fields];
      newFields[index].options.push('');
      setFields(newFields);
    }
  };

  // Logout function
  const logout = () => {
    localStorage.removeItem("usersdatatoken");
    setLoginData(null);
    history("/");
  };

  if (isLoading) return <CircularProgress />;

  return (
    <div>
      <h1>Welcome to Dashboard</h1>
      <p>User Email: {logindata?.email}</p>

      <h2>Create a New Form</h2>
      <form onSubmit={handleFormSubmit}>
        <input
          type="text"
          placeholder="Form Title"
          value={formTitle}
          onChange={(e) => setFormTitle(e.target.value)}
          required
        />
        {fields.map((field, index) => (
          <div key={index}>
            <input
              type="text"
              placeholder="Question"
              name="question"
              value={field.question}
              onChange={(e) => handleFieldChange(index, e)}
              required
            />
            <select
              name="type"
              value={field.type}
              onChange={(e) => handleFieldChange(index, e)}
            >
              <option value="text">Text</option>
              <option value="radio">Radio</option>
              <option value="checkbox">Checkbox</option>
            </select>
            {field.type !== 'text' && (
              <>
                {field.options.map((option, optIndex) => (
                  <input
                    key={optIndex}
                    type="text"
                    placeholder={`Option ${optIndex + 1}`}
                    value={option}
                    onChange={(e) => handleOptionChange(index, optIndex, e)}
                  />
                ))}
                <button type="button" onClick={() => addOptionField(index)}>Add Option</button>
              </>
            )}
            <button type="button" onClick={() => removeField(index)}>Remove</button>
          </div>
        ))}
        <button type="button" onClick={addField}>Add Question</button>
        <button type="submit">Create Form</button>
      </form>

      {/* Display forms and submissions */}
      {responses.map(form => (
        <div key={form.formId} className="form-box">
          {/* Add delete button here */}
          <button onClick={() => deleteForm(form.formId)} className="delete-button">×</button>
          <h3>{form.formTitle}</h3>

          {/* Share button to open the form in a new tab */}
          <button
            onClick={() => window.open(`${window.location.origin}/form/${form.formId}`, '_blank')}
            className="share-button"
          >
            Share Form
          </button>

          <h4>Submitted Users:</h4>
          {submissions.filter(submission => submission.formId === form.formId).map(submission => (
            <div key={submission._id}>
              <p><strong>Name:</strong> {submission.name}</p>
              <p><strong>Email ID:</strong> {submission.email}</p>
              {submission.selectedOptions.map((option, idx) => (
                <div key={idx}>
                  <strong>{option.question}:</strong> {Array.isArray(option.answer) ? option.answer.join(', ') : option.answer}
                </div>
              ))}
            </div>
          ))}
        </div>
      ))}

      {/* Snackbar for success messages */}
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={6000}
        onClose={() => setSnackbarOpen(false)}
      >
        <Alert onClose={() => setSnackbarOpen(false)} severity="success">
          {snackbarMessage}
        </Alert>
      </Snackbar>

      <button onClick={logout}>Log Out</button>

      {/* Show error if it exists */}
      {error && <p style={{ color: 'red' }}>{error}</p>}
    </div>
  );
};

export default Dashboard;

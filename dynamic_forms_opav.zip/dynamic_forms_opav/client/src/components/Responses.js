import React from 'react';

const Responses = ({ responses = [] }) => {
    return (
        <div>
            <h2>Responses</h2>
            {responses.map((response, index) => (
                <div key={index}>
                    <h3>{response.formTitle}</h3>
                    {response.fields.map((field, idx) => (
                        <div key={idx}>
                            <p>{field.question}:</p>
                            {field.type === 'text' ? (
                                <p>{field.answer}</p>
                            ) : (
                                field.options.map((option, optIdx) => (
                                    <p key={optIdx}>{option}</p>
                                ))
                            )}
                        </div>
                    ))}
                </div>
            ))}
        </div>
    );
};

export default Responses;
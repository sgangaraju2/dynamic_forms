import React, { useState } from 'react';

const FormBuilder = ({ onSubmit }) => {
    const [formTitle, setFormTitle] = useState('');
    const [fields, setFields] = useState([{ question: '', type: 'text', options: [] }]);

    const addField = () => {
        setFields([...fields, { question: '', type: 'text', options: [] }]);
    };

    const removeField = (index) => {
        setFields(fields.filter((_, i) => i !== index));
    };

    const handleFieldChange = (index, event) => {
        const newFields = [...fields];
        newFields[index][event.target.name] = event.target.value;
        if (event.target.name === 'type' && event.target.value !== 'checkbox') {
            newFields[index].options = [];
        }
        setFields(newFields);
    };

    const handleOptionChange = (fieldIndex, optionIndex, event) => {
        const newFields = [...fields];
        newFields[fieldIndex].options[optionIndex] = event.target.value;
        setFields(newFields);
    };

    const addOption = (index) => {
        const newFields = [...fields];
        newFields[index].options.push('');
        setFields(newFields);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        
        const formData = {
            formTitle,
            fields: fields.map(field => ({
                question: field.question,
                type: field.type,
                options: field.options.filter(option => option !== '')
            }))
        };

        onSubmit(formData);
    };

    return (
        <div>
            <h2>Create a New Form</h2>
            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    value={formTitle}
                    placeholder="Form Title"
                    onChange={(e) => setFormTitle(e.target.value)}
                    required
                />
                {fields.map((field, index) => (
                    <div key={index}>
                        <input
                            type="text"
                            name="question"
                            value={field.question}
                            placeholder="Question"
                            onChange={(e) => handleFieldChange(index, e)}
                            required
                        />
                        <select
                            name="type"
                            value={field.type}
                            onChange={(e) => handleFieldChange(index, e)}
                        >
                            <option value="text">Text</option>
                            <option value="radio">Single Option</option>
                            <option value="checkbox">Multiple Choice</option>
                        </select>
                        {['radio', 'checkbox'].includes(field.type) && (
                            <>
                                {field.options.map((option, optIndex) => (
                                    <input
                                        key={optIndex}
                                        type="text"
                                        value={option}
                                        placeholder={`Option ${optIndex + 1}`}
                                        onChange={(e) => handleOptionChange(index, optIndex, e)}
                                    />
                                ))}
                                <button type="button" onClick={() => addOption(index)}>Add Option</button>
                            </>
                        )}
                        {field.type === 'text' && (
                            <input
                                type="text"
                                placeholder="User Input"
                                disabled
                            />
                        )}
                        <button type="button" onClick={() => removeField(index)}>Remove</button>
                    </div>
                ))}
                <button type="button" onClick={addField}>Add Question</button>
                {/* <button type="submit">Create Form</button> */}
            </form>
        </div>
    );
};

export default FormBuilder;
import React, { useContext, useState } from 'react'
import { NavLink, useNavigate } from "react-router-dom"
import { ToastContainer, toast } from 'react-toastify';
import "./mix.css"
import { LoginContext } from './ContextProvider/Context';

const Login = () => {
    const { setLoginData } = useContext(LoginContext);
    const [passShow, setPassShow] = useState(false);
    const [inpval, setInpval] = useState({
        email: "",
        password: "",
    });

    const history = useNavigate();

    const setVal = (e) => {
        const { name, value } = e.target;
        setInpval(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const loginuser = async (e) => {
        e.preventDefault();

        const { email, password } = inpval;

        if (email === "") {
            toast.error("Email is required!");
        } else if (!email.includes("@")) {
            toast.warning("Include @ in your email!");
        } else if (password === "") {
            toast.error("Password is required!");
        } else if (password.length < 6) {
            toast.error("Password must be at least 6 characters!");
        } else {
            try {
                const response = await fetch("http://localhost:8009/api/login", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        email, password
                    })
                });

                const res = await response.json();
                console.log("Login response", res);

                if (res.status === 200) {  // Changed from 201 to 200 as per your server response
                    localStorage.setItem("usersdatatoken", res.result.token);
                    setLoginData({
                        ValidUserOne: res.result.user
                    });
                    toast.success("Login successful!");
                    setInpval({ email: "", password: "" });
                    history("/dash");
                } else {
                    toast.error(res.error || "Login failed. Please try again.");
                }
            } catch (error) {
                console.error("Login error:", error);
                toast.error("An error occurred. Please try again later.");
            }
        }
    }

    return (
        <>
            <section>
                <div className="form_data">
                    <div className="form_heading">
                        <h1>Welcome Back, Log In</h1>
                        <p>Hi, we are glad you are back. Please login.</p>
                    </div>

                    <form onSubmit={loginuser}>
                        <div className="form_input">
                            <label htmlFor="email">Email</label>
                            <input type="email" value={inpval.email} onChange={setVal} name="email" id="email" placeholder='Enter Your Email Address' />
                        </div>
                        <div className="form_input">
                            <label htmlFor="password">Password</label>
                            <div className="two">
                                <input 
                                    type={passShow ? "text" : "password"} 
                                    onChange={setVal} 
                                    value={inpval.password} 
                                    name="password" 
                                    id="password" 
                                    placeholder='Enter Your Password' 
                                />
                                <div className="showpass" onClick={() => setPassShow(!passShow)}>
                                    {passShow ? "Hide" : "Show"}
                                </div>
                            </div>
                        </div>

                        <button className='btn' type="submit">Login</button>
                        <p>Don't have an Account? <NavLink to="/register">Sign Up</NavLink></p>
                    </form>
                </div>
            </section>
            <ToastContainer />
        </>
    )
}

export default Login
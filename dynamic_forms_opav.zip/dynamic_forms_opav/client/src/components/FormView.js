import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';

const FormView = () => {
  const [form, setForm] = useState(null);
  const [formData, setFormData] = useState({ name: '', email: '', selectedOptions: {} });
  const { formId } = useParams();

  useEffect(() => {
    const fetchForm = async () => {
      try {
        const response = await fetch(`http://localhost:8009/api/form/${formId}`);
        if (response.ok) {
          const data = await response.json();
          setForm(data.form);
        } else {
          throw new Error('Form not found');
        }
      } catch (error) {
        console.error('Error fetching form:', error);
      }
    };
    fetchForm();
  }, [formId]);

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleOptionChange = (fieldIndex, selectedOption) => {
    setFormData({
      ...formData,
      selectedOptions: { ...formData.selectedOptions, [fieldIndex]: selectedOption },
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    // Check if name, email, and all questions are filled
    if (!formData.name || !formData.email || Object.keys(formData.selectedOptions).length !== form.fields.length) {
      alert('Please fill out all fields before submitting.');
      return;
    }
  
    try {
      const selectedOptionsArray = Object.entries(formData.selectedOptions).map(([index, answer]) => ({
        question: form.fields[index]?.question,
        answer: Array.isArray(answer) ? answer : [answer],
      }));
  
      const submissionDataObject = {
        ...formData,
        selectedOptions: selectedOptionsArray,
      };
  
      console.log('Submitting data:', submissionDataObject);
  
      const response = await fetch(`http://localhost:8009/api/form/${formId}/submit`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(submissionDataObject),
      });
  
      if (response.ok) {
        alert('Form submitted successfully');
        setFormData({ name: '', email: '', selectedOptions: {} });
      } else {
        throw new Error('Failed to submit form');
      }
    } catch (error) {
      console.error('Error submitting form:', error);
    }
  };

  if (!form) return <div>Loading...</div>;

  return (
    <div>
      <h1>{form.formTitle}</h1>
      <form onSubmit={handleSubmit}>
        {form.fields.map((field, index) => (
          <div key={index}>
            <label>{field.question}</label>
            {field.type === 'text' && (
              <input
                type='text'
                name={`question_${index}`}
                value={formData.selectedOptions[index] || ''}
                onChange={(e) => handleOptionChange(index, e.target.value)}
              />
            )}
            {field.type === 'radio' && field.options.map((option, optIndex) => (
              <div key={optIndex}>
                <input
                  type='radio'
                  name={`question_${index}`}
                  value={option}
                  checked={formData.selectedOptions[index] === option}
                  onChange={() => handleOptionChange(index, option)}
                />
                <label>{option}</label>
              </div>
            ))}
            {field.type === 'checkbox' && field.options.map((option, optIndex) => (
              <div key={optIndex}>
                <input
                  type='checkbox'
                  name={`question_${index}`}
                  value={option}
                  checked={(formData.selectedOptions[index] || []).includes(option)}
                  onChange={(e) => {
                    let newSelections = formData.selectedOptions[index] || [];
                    if (e.target.checked) {
                      newSelections.push(option);
                    } else {
                      let indexToRemove = newSelections.indexOf(option);
                      newSelections.splice(indexToRemove, 1);
                    }
                    handleOptionChange(index, newSelections);
                  }}
                />
                <label>{option}</label>
              </div>
            ))}
          </div>
        ))}
        <div>
          <label>Name:</label>
          <input
            type='text'
            name='name'
            value={formData.name}
            onChange={handleInputChange}
          />
        </div>
        <div>
          <label>Email ID:</label>
          <input
            type='email'
            name='email'
            value={formData.email}
            onChange={handleInputChange}
          />
        </div>
        <button type='submit'>Submit</button>
      </form>

      {/* Display submitted data */}
      <h2>Submitted Data</h2>
      <p><strong>Name:</strong> {formData.name}</p>
      <p><strong>Email ID:</strong> {formData.email}</p>
      {Object.entries(formData.selectedOptions).map(([index, answer]) => (
        <div key={index}>
          <strong>{form.fields[index]?.question}:</strong> {Array.isArray(answer) ? answer.join(', ') : answer}
        </div>
      ))}
    </div>
  );
};

export default FormView;
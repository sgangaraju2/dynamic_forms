const jwt = require("jsonwebtoken");
const userdb = require("../models/userSchema");
const keysecret = "key";

const authenticate = async (req, res, next) => {
  try {
    let token = req.headers.authorization;

    // Check if the token exists
    if (!token) {
      throw new Error("No token provided");
    }

    // Remove 'Bearer ' if it's included in the token
    if (token.startsWith('Bearer ')) {
      token = token.slice(7);
    }

    const verifytoken = jwt.verify(token, keysecret);
    const rootUser = await userdb.findOne({_id: verifytoken._id});

    if (!rootUser) {
      throw new Error("User not found");
    }

    req.token = token;
    req.rootUser = rootUser;
    req.userId = rootUser._id;

    next();
  } catch (error) {
    console.error("Authentication error:", error.message);
    res.status(401).json({status: 401, message: "Unauthorized: " + error.message});
  }
};

module.exports = authenticate;
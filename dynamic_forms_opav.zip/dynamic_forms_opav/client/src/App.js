import Header from "./components/Header";
import Login from "./components/Login"
import { Routes, Route, useNavigate } from "react-router-dom"
import Register from "./components/Register";
import Dashboard from "./components/Dashboard";
import Error from "./components/Error";
import Context from './components/ContextProvider/Context';
import FormView from "./components/FormView";

function App() {
  return (
 
  <Context>
  <Header/>
  

            <Routes>
              <Route path="/" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/dash" element={<Dashboard />} />
              <Route path="/form/:formId" element={<FormView />} /> {/* Add this route */}
              <Route path="*" element={<Error />} />
              </Routes>
              </Context>
  

  );
}

export default App;

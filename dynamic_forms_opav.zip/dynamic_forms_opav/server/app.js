const express = require("express");
const app = express();
require("./db/conn");
const router = require("./routes/router");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const path = require("path");
require('dotenv').config();

const port = process.env.PORT || 8009;

// Middleware
app.use(cors({
    origin: 'http://localhost:3000', // or your React app's URL
    credentials: true
}));
app.use(express.json());
app.use(cookieParser());

// Logging middleware
app.use((req, res, next) => {
    // console.log(`Received ${req.method} request for ${req.url}`);
    // console.log("Headers:", req.headers);
    next();
});

// API routes
app.use("/api", router);

// Serve static files from the React app
app.use(express.static(path.join(__dirname, 'client/build')));

// The "catch-all" handler: for any request that doesn't
// match one above, send back React's index.html file.
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'client/build', 'index.html'));
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
// models/Submission.js
const mongoose = require('mongoose');

const submissionSchema = new mongoose.Schema({
  formId: String,
  userId: String,
  name: String,
  email: String,
  selectedOptions: [
    {
      question: String,
      answer: mongoose.Schema.Types.Mixed // can store string, array, or other types based on the answer format
    }
  ],
  submittedAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Submission', submissionSchema);

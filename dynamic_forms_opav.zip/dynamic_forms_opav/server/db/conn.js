const mongoose = require("mongoose");

const DB = "mongodb+srv://user:forms@dynamicforms.hqsm9.mongodb.net/db?retryWrites=true&w=majority&appName=dynamicforms"



mongoose.connect(DB,{
    useUnifiedTopology: true,
    useNewUrlParser: true
}).then(()=> console.log("DataBase Connected")).catch((errr)=>{
    console.log(errr);
})

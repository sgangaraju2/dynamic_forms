
const express = require("express");
const bcrypt = require("bcrypt");
const userdb = require("../models/userSchema");
const router = new express.Router();
const authenticate = require("../middleware/authenticate");
const Submission = require('../models/submissionSchema');

// User registration
router.post("/register", async (req, res) => {
    const { fname, email, password, cpassword } = req.body;
    if (!fname || !email || !password || !cpassword) {
        return res.status(422).json({ error: "Fill all the details" });
    }

    try {
        const preuser = await userdb.findOne({ email: email });
        if (preuser) {
            return res.status(422).json({ error: "This Email already exists" });
        }

        if (password !== cpassword) {
            return res.status(422).json({ error: "Password and Confirm Password do not match" });
        }

        const finalUser = new userdb({
            fname, email, password,
            forms: [] // Initialize forms array for new users
        });
        const storeData = await finalUser.save();
        res.status(201).json({ status: 201, storeData });
    } catch (error) {
        console.error("Registration error:", error);
        res.status(500).json({ error: "Internal server error" });
    }
});

router.post("/login", async (req, res) => {
    const { email, password } = req.body;
    try {
      const userValid = await userdb.findOne({ email });
      if (!userValid) {
        return res.status(401).json({ error: "Invalid email or password" });
      }
  
      const isMatch = await bcrypt.compare(password, userValid.password);
      if (!isMatch) {
        return res.status(401).json({ error: "Invalid email or password" });
      }
  
      let token;
      try {
        token = await userValid.generateAuthtoken();
        res.cookie("usercookie", token, {
          expires: new Date(Date.now() + 9000000),
          httpOnly: true
        });
        res.status(200).json({
          status: 200,
          message: "Login successful",
          result: { userValid, token }
        });
      } catch (tokenError) {
        console.error("Token generation error:", tokenError);
        return res.status(500).json({ error: "Error generating authentication token" });
      }
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

router.get("/validuser", authenticate, async (req, res) => {
    try {
        const validUser = await userdb.findOne({_id: req.userId});
        if (!validUser) {
            return res.status(404).json({ status: 404, error: "User not found" });
        }
        res.status(200).json({ status: 200, validUser });
    } catch (error) {
        console.error("User validation error:", error);
        res.status(500).json({ status: 500, error: "Internal server error" });
    }
});

// Logout user
router.get("/logout", authenticate, async (req, res) => {
    try {
        req.rootUser.tokens = req.rootUser.tokens.filter((curtoken) => curtoken.token !== req.token);
        res.clearCookie("usercookie", { path: "/" });
        await req.rootUser.save();
        res.status(200).json({ status: 200, message: "User logged out successfully" });
    } catch (error) {
        console.error("Logout error:", error);
        res.status(500).json({ status: 500, error: "Internal server error" });
    }
});

// Save form data
router.post("/forms", authenticate, async (req, res) => {
    try {
        const { formTitle, fields, formId } = req.body;
        const userId = req.userId;
        
        await userdb.updateOne(
            { _id: userId },
            { $push: { forms: { formTitle, fields, formId } } }
        );
        
        res.status(200).json({ message: "Form data saved successfully" });
    } catch (error) {
        console.error("Error saving form data:", error);
        res.status(500).json({ error: "Internal server error" });
    }
});

// Get forms
router.get("/forms", authenticate, async (req, res) => {
    try {
        const userId = req.userId;
        const user = await userdb.findById(userId);
        
        // Return an empty array if no forms are found
        if (!user || !user.forms.length) {
            return res.status(200).json({ forms: [] });
        }
        
        res.status(200).json({ forms: user.forms });
    } catch (error) {
        console.error("Error fetching form data:", error);
        res.status(500).json({ error: "Internal server error" });
    }
});

// Get form by ID
router.get("/form/:formId", async (req, res) => {
    try {
      const { formId } = req.params;
      const form = await userdb.findOne({ "forms.formId": formId }, { "forms.$": 1 });

      if (!form || !form.forms.length) {
          return res.status(404).json({ message: "Form not found" });
      }

      res.status(200).json({ form: form.forms[0] });
  } catch (error) {
      console.error("Error fetching form:", error);
      res.status(500).json({ error: "Internal server error" });
  }
});

// Form submission endpoint
router.post('/form/:formId/submit', async (req, res) => {
    try {
      const { formId } = req.params;
      const { name, email, selectedOptions } = req.body;
      const userId = req.userId;  // Assuming `authenticate` middleware sets `req.userId`
  
      const newSubmission = new Submission({
        formId,
        name,
        email,
        selectedOptions
      });
  
      await newSubmission.save();
      res.status(200).json({ message: 'Form submitted successfully' });
    } catch (error) {
      console.error('Error submitting form:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });


// Fetch submissions for a specific user's forms
router.get('/submissions', authenticate, async (req, res) => {
    try {
      const userId = req.userId;
      
      // Find forms created by this user
      const user = await userdb.findById(userId);
      if (!user || !user.forms.length) {
        return res.status(200).json({ submissions: [] });
      }
  
      // Extract form IDs created by this user
      const formIds = user.forms.map(form => form.formId);
  
      // Fetch submissions for these forms
      const submissions = await Submission.find({ formId: { $in: formIds } });
  
      res.status(200).json({ submissions });
    } catch (error) {
      console.error('Error fetching submissions:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  
  
  router.delete("/forms/:formId", authenticate, async (req, res) => {
    console.log("Delete route handler started");
    try {
      const { formId } = req.params;
      const userId = req.userId;

      console.log("Attempting to delete formId:", formId, "for userId:", userId);
  
      console.log("Received DELETE request for formId:", formId);
  
      const user = await userdb.findOneAndUpdate(
        { _id: userId },
        { $pull: { forms: { formId } } },
        { new: true }
      ).catch(err => {
        console.error("Error in findOneAndUpdate:", err);
        return null;
      });
  
      if (!user) {
        console.error("Form not found or not authorized for user ID:", userId);
        return res.status(404).json({ error: "Form not found or not authorized" });
      }
  
      await Submission.deleteMany({ formId });
  
      console.log("Form deleted successfully for user ID:", userId);
      res.status(200).json({ message: "Form deleted successfully" });
    } catch (error) {
      console.error("Error deleting form:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });



module.exports = router;